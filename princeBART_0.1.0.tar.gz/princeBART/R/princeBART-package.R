#' princeBART: Principal Stratification with BART
#'
#' @description
#' The princeBART package implements principal stratification for causal
#' inference with endogenous treatments using Bayesian Additive Regression
#' Trees (BART). It estimates treatment effects for compliers—units whose
#' treatment status is affected by an instrument.
#'
#' @section Main Functions:
#' \itemize{
#'   \item \code{\link{fit_psbart}}: Fit a single-chain principal stratification BART model
#'   \item \code{\link{mc_psbart}}: Run multiple chains in parallel
#' }
#'
#' @section Estimands:
#' \itemize{
#'   \item \code{\link{mate_c}}: Mixture Average Treatment Effect for Compliers
#'   \item \code{\link{matt_c}}: Mixture ATT for Compliers
#'   \item \code{\link{sate_c}}: Sample Average Treatment Effect for Compliers
#'   \item \code{\link{satt_c}}: Sample ATT for Compliers
#' }
#'
#' @section Model:
#' The model applies to settings with an instrument Z, an endogenous treatment W,
#' and an outcome Y. It requires conditional randomization of Z given covariates X,
#' and allows for both one-sided and two-sided noncompliance.
#' Three principal strata are identified:
#' \itemize{
#'   \item \strong{Compliers}: W(1) = 1, W(0) = 0 — treatment responds to instrument
#'   \item \strong{Never-takers}: W(1) = W(0) = 0 — never treated regardless of Z
#'   \item \strong{Always-takers}: W(1) = W(0) = 1 — always treated regardless of Z
#' }
#'
#' BART is used to flexibly model both the stratum membership probabilities
#' and the potential outcomes within each stratum, allowing for heterogeneous
#' effects across covariate values.
#'
#' @docType package
#' @name princeBART-package
#' @aliases princeBART
#'
#' @importFrom dbarts dbarts bart2 dbartsControl dbartsData
#' @importFrom posterior as_draws_array
#' @importFrom abind abind
#' @importFrom future.apply future_lapply
#' @importFrom stats pnorm qnorm rbinom lm coef fitted model.frame model.matrix model.response formula
#' @importFrom methods new
#' @importFrom parallel detectCores
#' @importFrom future plan multisession
#' @importFrom Formula Formula
#' @importFrom utils getFromNamespace
"_PACKAGE"
