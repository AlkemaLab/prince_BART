#' Multi-Chain Principal Stratification BART
#'
#' Runs multiple chains of \code{fit_psbart} in parallel using the
#' \code{future} framework for cross-platform compatibility.
#'
#' @param formula A formula following 2SLS convention: \code{Y ~ X1 + X2 | Z | W}
#'   where Y is the outcome, X1 + X2 are covariates, Z is the instrument
#'   (treatment assignment), and W is treatment uptake.
#' @param data A data.frame containing the variables in the formula.
#' @param X A matrix or data.frame of covariates. Used when \code{formula = NULL}.
#' @param Y A binary outcome vector (0/1). Used when \code{formula = NULL}.
#' @param Z A binary treatment assignment/instrument vector (0/1).
#' @param W A binary treatment uptake/received vector (0/1).
#' @param propensity Optional pre-computed propensity scores. If NULL (default),
#'   propensity scores are estimated internally using BART.
#' @param instrument_overlap Optional bounds for instrument propensity trimming
#'   to enforce overlap. If provided as a length-2 vector (e.g., \code{c(0.1, 0.9)}),
#'   observations with estimated propensity scores outside this range are excluded.
#'   Default is NULL (no trimming). See Crump et al. (2009) for justification.
#' @param n_chains Number of parallel chains to run (default: 4).
#' @param n_warmup Number of warmup iterations per chain (default: 1000).
#' @param n_samples Number of posterior samples per chain (default: 1000).
#' @param keep_trees Logical; save tree structures (default: FALSE).
#' @param k Prior hyperparameter for node mean prior (default: 2).
#' @param n_trees Number of trees in the BART ensemble (default: 200).
#' @param n_initial Number of initial iterations using MoM offsets (default: 20).
#' @param workers Number of parallel workers. If NULL (default), uses all
#'   available cores up to \code{n_chains}. Set to 1 for sequential execution.
#' @param verbose Logical; print progress messages (default: FALSE).
#'
#' @details
#' Uses \code{future.apply::future_lapply} for parallelization. Before calling
#' this function, set your preferred parallel backend:
#'
#' \preformatted{
#' # For Unix/Mac (forked processes)
#' future::plan(future::multicore)
#'
#' # For Windows or any platform (separate R sessions)
#' future::plan(future::multisession)
#' }
#'
#' @return A list of class \code{"princebart"} containing combined results
#'   from all chains:
#'   \item{imp}{4D array of imputed compliance classes (iteration x chain x variable x unit)}
#'   \item{probs}{4D array of probabilities (iteration x chain x variable x unit)}
#'   \item{trees}{Combined tree structures if \code{keep_trees = TRUE}}
#'   \item{data}{Original data as list with X (including e), Y, Z, W}
#'
#' @examples
#' \dontrun{
#' library(future)
#' plan(multisession, workers = 4)  # Works on all platforms
#'
#' # Formula interface (2SLS style)
#' fit <- mc_psbart(Y ~ X1 + X2 + X3 | Z | W, data = mydata,
#'                  n_chains = 4, n_warmup = 1000, n_samples = 1500)
#'
#' # Matrix interface
#' fit <- mc_psbart(X = covariates, Y = outcome, Z = assignment, W = uptake,
#'                  n_chains = 4, n_warmup = 1000, n_samples = 1500)
#'
#' # Extract treatment effects
#' mate_c(fit)  # Mixture ATE for compliers
#' sate_c(fit)  # Sample ATE for compliers
#' }
#'
#' @seealso \code{\link{fit_psbart}}, \code{\link{mate_c}}, \code{\link{sate_c}}
#'
#' @export
mc_psbart <- function(
  formula = NULL,
  data = NULL,
  X = NULL,
  Y = NULL,
  Z = NULL,

  W = NULL,
  propensity = NULL,
  instrument_overlap = NULL,
  n_warmup = 1000L,
  n_samples = 1000L,
  n_chains = 4L,
  keep_trees = FALSE,
  k = 2,
  n_trees = 200L,
  n_initial = 20L,
  workers = NULL,
  verbose = FALSE
) {

  # Handle formula interface
  if (!is.null(formula)) {
    parsed <- parse_psbart_formula(formula, data)
    X <- parsed$X
    Y <- parsed$Y
    Z <- parsed$Z
    W <- parsed$W
  }

  # Input validation
  if (is.null(X) || is.null(Y) || is.null(Z) || is.null(W)) {
    stop("Must provide either a formula + data, or X, Y, Z, W directly")
  }

  # Validate and prepare data
  X <- validate_and_prepare_X(X)
  Y <- validate_binary(Y, "Y")
  Z <- validate_binary(Z, "Z")
  W <- validate_binary(W, "W")

  n <- nrow(X)
  if (length(Y) != n || length(Z) != n || length(W) != n) {
    stop("X, Y, Z, W must all have the same number of observations")
  }

  # Store scaling attributes before adding e
  scaled_center <- attr(X, "scaled:center")
  scaled_scale <- attr(X, "scaled:scale")

  # Compute propensity scores
  if (is.null(propensity)) {
    if (verbose) message("Computing propensity scores...")
    e <- dbarts::bart2(X, Z, verbose = FALSE) |> stats::fitted() |> stats::qnorm()
  } else {
    validate_propensity(propensity, n)
    e <- stats::qnorm(propensity)
  }

  # Enforce instrument overlap by trimming extreme propensity scores
  if (!is.null(instrument_overlap)) {
    if (length(instrument_overlap) != 2) {
      stop("instrument_overlap must be a length-2 vector, e.g., c(0.1, 0.9)")
    }
    e_prob <- stats::pnorm(e)
    keep <- e_prob >= instrument_overlap[1] & e_prob <= instrument_overlap[2]
    n_trimmed <- sum(!keep)
    if (verbose) {
      message("Trimming ", n_trimmed, " observations (",
              round(100 * n_trimmed / n, 1), "%) outside propensity range [",
              instrument_overlap[1], ", ", instrument_overlap[2], "]")
    }
    if (sum(keep) < 10) {
      stop("Too few observations remain after instrument overlap trimming")
    }
    X <- X[keep, , drop = FALSE]
    Y <- Y[keep]
    Z <- Z[keep]
    W <- W[keep]
    e <- e[keep]
    n <- sum(keep)
  }

  # Append propensity to X
  X <- cbind(X, e = e)
  
  # Preserve scaling attributes on X (for general_BART)
  attr(X, "scaled:center") <- scaled_center
  attr(X, "scaled:scale") <- scaled_scale

  # Determine number of workers
  if (is.null(workers)) {
    workers <- min(parallel::detectCores(), n_chains)
  }

  # Set up future plan if not already configured
  old_plan <- future::plan()
  if (inherits(old_plan, "sequential") && workers > 1) {
    if (verbose) message("Setting up multisession plan with ", workers, " workers")
    future::plan(future::multisession, workers = workers)
    on.exit(future::plan(old_plan), add = TRUE)
  }

  if (verbose) message("Running ", n_chains, " chains...")

  # Run chains in parallel
  res0 <- future.apply::future_lapply(
    seq_len(n_chains),
    function(chain_id) {
      fit_psbart(
        X = X,
        Y = Y,
        Z = Z,
        W = W,
        n_warmup = n_warmup,
        n_samples = n_samples,
        save_trees = keep_trees,
        k = k,
        n_trees = n_trees,
        n_initial = n_initial,
        verbose = FALSE
      )
    },
    future.seed = TRUE
  )

  # Combine results
  res <- list()

  # Combine trees
  if (keep_trees) {
    list_tree <- lapply(res0, function(x) x$trees)
    res$trees <- do.call(rbind, Map(function(df, id) {
      df$chain <- id
      df
    }, list_tree, seq_along(list_tree)))
  } else {
    res$trees <- NULL
  }

  # Combine imputations
  list_imp <- lapply(res0, function(x) x$imputed)
  res$imp <- abind::abind(list_imp, along = 4)
  res$imp <- aperm(res$imp, c(1, 4, 3, 2))
  dimnames(res$imp) <- list(
    iteration = NULL,
    chain = NULL,
    variable = c("nt", "at"),
    unit = NULL
  )

  # Combine probabilities
  list_probs <- lapply(res0, function(x) x$probs)
  res$probs <- abind::abind(list_probs, along = 4)
  res$probs <- aperm(res$probs, c(1, 4, 3, 2))
  dimnames(res$probs) <- list(
    iteration = NULL,
    chain = NULL,
    variable = c("p_n", "p_a", "m_y0c", "m_y1c", "m_y0n", "m_y1a"),
    unit = NULL
  )

  # Store data reference with UNSCALED X (for general_BART compatibility)
  # X is currently scaled; unscale before storing
  X_unscaled <- X[, -ncol(X), drop = FALSE]  # Remove e column first
  if (!is.null(scaled_center) && !is.null(scaled_scale)) {
    # Reverse scaling: X_original = X_scaled * scale + center
    for (j in seq_len(ncol(X_unscaled))) {
      v <- colnames(X_unscaled)[j]
      if (v %in% names(scaled_center) && v %in% names(scaled_scale)) {
        X_unscaled[, j] <- X_unscaled[, j] * scaled_scale[v] + scaled_center[v]
      }
    }
  }
  # Add back e (propensity is not scaled)
  X_unscaled <- cbind(X_unscaled, e = X[, "e"])
  
  res$data <- list(X = X_unscaled, Y = Y, Z = Z, W = W)
  
  # Store scaling parameters separately for use in predictions
  res$scaling <- list(
    center = scaled_center,
    scale = scaled_scale
  )
  
  res$call <- match.call()

  class(res) <- "princebart"
  
  if (verbose) message("Done.")
  res
}
