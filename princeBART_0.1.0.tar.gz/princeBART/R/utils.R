#' Parse Principal Stratification Formula
#'
#' Parses a formula in 2SLS style: Y ~ X1 + X2 | Z | W
#'
#' @param formula A formula with three parts separated by |
#' @param data A data.frame containing the variables
#'
#' @return A list with components X, Y, Z, W
#'
#' @keywords internal
parse_psbart_formula <- function(formula, data) {
  if (is.null(data)) {
    stop("data argument is required when using formula interface")
  }

  # Convert to Formula object for multi-part handling
  f <- Formula::Formula(formula)

  # Check formula structure
  n_rhs <- length(f)[2]
  if (n_rhs != 3) {
    stop("Formula must have 3 right-hand-side parts: Y ~ covariates | Z | W\n",
         "  Example: outcome ~ x1 + x2 + x3 | assignment | uptake")
  }

  # Extract outcome (Y)
  Y <- stats::model.response(stats::model.frame(f, data = data, lhs = 1, rhs = 0))

  # Extract covariates (X) - first RHS part
  X_formula <- stats::formula(f, lhs = 0, rhs = 1)
  X_frame <- stats::model.frame(X_formula, data = data)
  X <- stats::model.matrix(X_formula, data = X_frame)
  # Remove intercept if present
  if ("(Intercept)" %in% colnames(X)) {
    X <- X[, colnames(X) != "(Intercept)", drop = FALSE]
  }

  # Extract Z (instrument/assignment) - second RHS part
  Z_formula <- stats::formula(f, lhs = 0, rhs = 2)
  Z_frame <- stats::model.frame(Z_formula, data = data)
  Z <- stats::model.matrix(Z_formula, data = Z_frame)
  if ("(Intercept)" %in% colnames(Z)) {
    Z <- Z[, colnames(Z) != "(Intercept)", drop = FALSE]
  }
  if (ncol(Z) != 1) {
    stop("Z (instrument) must be a single variable")
  }
  Z <- as.vector(Z)

  # Extract W (uptake) - third RHS part
  W_formula <- stats::formula(f, lhs = 0, rhs = 3)
  W_frame <- stats::model.frame(W_formula, data = data)
  W <- stats::model.matrix(W_formula, data = W_frame)
  if ("(Intercept)" %in% colnames(W)) {
    W <- W[, colnames(W) != "(Intercept)", drop = FALSE]
  }
  if (ncol(W) != 1) {
    stop("W (uptake) must be a single variable")
  }
  W <- as.vector(W)

  list(X = X, Y = Y, Z = Z, W = W)
}


#' Internal Binary BART Wrapper
#'
#' A simplified wrapper that uses dbarts::dbarts directly and ensures
#' binary outcomes are handled correctly.
#'
#' @param x Predictor matrix.
#' @param y Response vector.
#' @param test Test predictor matrix.
#' @param subset Logical vector for subsetting training data.
#' @param offset Offset values for training data.
#' @param control A dbartsControl object.
#' @param k Prior hyperparameter for node prior (default 2).
#'
#' @return A dbartsSampler object.
#'
#' @keywords internal
dbarts_binary <- function(
  x, y, test = NULL, subset = NULL, offset = NULL,
  control = dbarts::dbartsControl(),
  k = 2
) {
  # Force binary mode in control for 0/1 outcomes
  control@binary <- TRUE

  # Get the normal function from dbarts
  normal_prior <- utils::getFromNamespace("normal", "dbarts")

  # Create the sampler using do.call to pass arguments properly
  args <- list(
    formula = x,
    data = y,
    test = test,
    control = control,
    node.prior = normal_prior(k),
    resid.prior = utils::getFromNamespace("fixed", "dbarts")(1),
    sigma = 1  # Required for binary but ignored
  )

  # Add optional arguments only if provided
  if (!is.null(subset)) args$subset <- subset
  if (!is.null(offset)) {
    args$offset <- offset
    args$offset.test <- offset
  }

  sampler <- do.call(dbarts::dbarts, args)
  sampler
}
