## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = FALSE
)

## ----install------------------------------------------------------------------
# # From GitHub
# devtools::install_github("yourusername/prince_BART")

## ----simulate-data------------------------------------------------------------
# set.seed(42)
# n <- 500
# 
# # Covariates
# X <- data.frame(
#   age = rnorm(n, 40, 10),
#   education = rnorm(n, 12, 3),
#   income = rnorm(n, 50000, 15000)
# )
# 
# # Principal strata (latent)
# # Probability of being a complier depends on covariates
# p_complier <- plogis(-1 + 0.02 * X$age + 0.1 * X$education)
# p_always   <- 0.1
# p_never    <- pmax(1 - p_complier - p_always, 0)
# 
# 
# strata <- sapply(1:n, function(i) {
#   sample(c("complier", "never", "always"), 1,
#          prob = c(p_complier[i], p_never[i], p_always))
# })
# 
# # Instrument (randomized, possibly conditional on X)
# Z <- rbinom(n, 1, 0.5)
# 
# # Treatment uptake depends on strata and instrument
# W <- Z
# W[strata == "always"] <- 1L
# W[strata == "never"]  <- 0L
# 
# # Potential outcomes (only Y(W) is observed)
# # True CACE = 0.3
# Y0 <- plogis(-0.5 + 0.01 * X$age + 0.05 * X$education)
# Y1 <- plogis(-0.2 + 0.01 * X$age + 0.05 * X$education)  # ~0.3 higher
# 
# Y <- rbinom(n, 1, ifelse(W == 1, Y1, Y0))
# 
# # Combine into data frame
# simdata <- data.frame(X, Z = Z, W = W, Y = Y)

## ----formula-usage------------------------------------------------------------
# library(princeBART)
# library(future)
# 
# # Set up parallel backend (works on all platforms)
# plan(multisession, workers = 4)
# 
# # Fit the model
# fit <- mc_psbart(
#   Y ~ age + education + income | Z | W,
#   data = simdata,
#   n_chains = 4,
#   n_warmup = 200,
#   n_samples = 300,
#   instrument_overlap = c(0.1, 0.9),  # Crump et al. (2009) recommendation
#   keep_trees = TRUE  # Save trees for generalization
# )
# 
# # Print summary
# print(fit)

## ----estimands----------------------------------------------------------------
# # Summary shows strata distribution and treatment effect
# summary(fit)
# 
# # Mixed ATE for Compliers (default)
# coef(fit)
# 
# 

## ----simulate-external--------------------------------------------------------
# set.seed(123)
# n_external <- 2000
# 
# # External population has different X distribution
# external_data <- data.frame(
#   age = rnorm(n_external, 45, 12),       # Slightly older
# 
#   education = rnorm(n_external, 11, 4)     # More variable education
#   # Note: income is NOT available in external data
# )
# 
# # Survey design: 100 PSUs with varying sizes
# external_data$psu <- sample(1:100, n_external, replace = TRUE)
# external_data$weight <- runif(n_external, 0.5, 2)  # Survey weights
# 
# # Define a target subpopulation (e.g., adults under 60)
# external_data$eligible <- external_data$age < 60

## ----general-bart-------------------------------------------------------------
# # Generalize treatment effects to external population
# # Missing variables are auto-detected and imputed
# pate_result <- general_BART(
#   princebart_fit = fit,
#   newdata = external_data,
#   subpop = external_data$eligible,       # Target subpopulation
#   psu = external_data$psu,               # PSU for survey inference
#   weights = external_data$weight,        # Survey weights
#   n_cores = 4,
#   verbose = TRUE
# )
# 
# # View results
# print(pate_result)

## ----pate-summary-------------------------------------------------------------
# # Detailed summary
# summary(pate_result)
# 
# # Access posterior draws for custom analyses
# hist(pate_result$draws,
#      main = "Posterior Distribution of PATE",
#      xlab = "Treatment Effect")
# abline(v = pate_result$pate, col = "red", lwd = 2)
# abline(v = pate_result$ci, col = "red", lty = 2)

## ----overlap-analysis---------------------------------------------------------
# # Compute overlap scores from the fitted general_pate object
# overlap <- general_BART_overlap(
#   object = pate_result,
#   verbose = TRUE
# )
# 
# # View overlap metrics
# head(overlap$overlap)
# 
# # Plot overlap diagnostics
# plot_overlap(overlap)

## ----overlap-trimming---------------------------------------------------------
# # Trim observations with |e_s_tilde| > 2 (i.e., outliers)
# overlap_trimmed <- general_BART_overlap(
#   object = pate_result,
#   threshold = 2,           # Standardized score threshold
#   overlap_value = "zero",  # Set tau = 0 for trimmed units
#   verbose = TRUE
# )
# 
# # Compare trimmed vs original PATE
# cat("Original PATE:", round(pate_result$pate, 4), "\n")
# cat("Trimmed PATE: ", round(overlap_trimmed$pate_trimmed, 4), "\n")
# cat("Units trimmed:", overlap_trimmed$n_trimmed, "\n")

## ----sensitivity--------------------------------------------------------------
# # Sensitivity analysis with gamma = 2
# # This computes bounds on PATE under worst-case weight perturbations
# sens <- general_BART_transportability(
#   object = pate_result,
#   gamma = 2,        # Allow weights to vary by factor of 2
#   n_sample = 100,   # Number of posterior draws to use
#   verbose = TRUE
# )
# 
# # View sensitivity bounds
# cat("Gamma =", sens$gamma, "\n")
# cat("Lower bound:", round(sens$lower$estimate, 4),
#     "[", round(sens$lower$ci[1], 4), ",", round(sens$lower$ci[2], 4), "]\n")
# cat("Upper bound:", round(sens$upper$estimate, 4),
#     "[", round(sens$upper$ci[1], 4), ",", round(sens$upper$ci[2], 4), "]\n")

## ----sensitivity-curve--------------------------------------------------------
# # Sensitivity curve for multiple gamma values
# gammas <- c(1.1, 1.25, 1.5, 2, 3)
# sens_results <- lapply(gammas, function(g) {
#   general_BART_transportability(pate_result, gamma = g)
# })
# 
# # Extract bounds
# lower_bounds <- sapply(sens_results, function(x) x$lower$estimate)
# upper_bounds <- sapply(sens_results, function(x) x$upper$estimate)
# 
# # Plot sensitivity curve
# plot(gammas, upper_bounds, type = "l", col = "red",
#      ylim = range(c(lower_bounds, upper_bounds)),
#      xlab = "Gamma", ylab = "PATE Bounds", main = "Sensitivity Analysis")
# lines(gammas, lower_bounds, col = "blue")
# abline(h = 0, lty = 2)
# abline(h = pate_result$pate, lty = 3)
# legend("topright", c("Upper", "Lower", "Null", "Point est."),
#        col = c("red", "blue", "black", "black"), lty = c(1, 1, 2, 3))

